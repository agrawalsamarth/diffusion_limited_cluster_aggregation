#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 16:29:44 2023

@author: samarth
"""

from py_postp import postp

filename = 5

test = postp.postprocessing()
test.set_a()
test.print_a()