#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 16:28:06 2023

@author: samarth
"""

def set_a(self, filename):
    
    self.a = filename
    
def print_a(self):
    
    print("a = {}".format(self.a))