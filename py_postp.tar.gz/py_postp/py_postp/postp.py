#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 15:06:58 2023

@author: samarth
"""

from funcs import set_a, print_a

class postprocessing:
    
    def __init__(self):             
        pass